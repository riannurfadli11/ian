package com.example.project_pertemuan5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
