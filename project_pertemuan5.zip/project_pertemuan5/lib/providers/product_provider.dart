import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product_model.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product_model.dart';

final productListProvider = Provider<List<Product>>((ref) {
  return [
    Product(
      id: '1',
      name: 'iPhone 15 Pro Max',
      category: 'Smartphone',
      price: 21999000,
      imageUrl: 'https://static0.pocketlintimages.com/wordpress/wp-content/uploads/163668-phones-news-ee-pocket-lint-awards-2022-best-flagship-phone-of-the-year-image2-xocht1p0z3.jpg?q=50&fit=crop&w=1600&h=900&dpr=1.5',
      description: 'Smartphone terbaru dengan chip A17 Pro',
      rating: 4.8,
      soldCount: 1234,
    ),
    Product(
      id: '2',
      name: 'Samsung Galaxy S24 Ultra',
      category: 'Smartphone',
      price: 19999000,
      imageUrl: 'https://images.samsung.com/id/smartphones/galaxy-s24-ultra/images/galaxy-s24-ultra-highlights-color-titanium-violet-back.jpg?imbypass=true',
      description: 'Smartphone dengan AI canggih',
      rating: 4.7,
      soldCount: 987,
    ),
    Product(
      id: '3',
      name: 'MacBook Pro M3',
      category: 'Laptop',
      price: 28999000,
      imageUrl: 'https://cdn.mos.cms.futurecdn.net/mGtVpw6rwwytsGGmYkyLem-1920-80.jpg.webp',
      description: 'Laptop profesional dengan chip M3',
      rating: 4.9,
      soldCount: 567,
    ),
    Product(
      id: '4',
      name: 'AirPods Pro 2',
      category: 'Audio',
      price: 2999000,
      imageUrl: 'https://img.antaranews.com/cache/1200x800/2019/12/30/airpods-pro-3_1.jpg.webp',
      description: 'Earbuds dengan noise cancellation',
      rating: 4.6,
      soldCount: 2345,
    ),
    Product(
      id: '5',
      name: 'iPad Pro 12.9"',
      category: 'Tablet',
      price: 15999000,
      imageUrl: 'https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111979_ipad-pro-12-2018.png',
      description: 'Tablet dengan chip M2',
      rating: 4.8,
      soldCount: 876,
    ),
  ];
});

// Cart Provider
final cartProvider = StateNotifierProvider<CartNotifier, List<CartItem>>((ref) {
  return CartNotifier();
});

class CartNotifier extends StateNotifier<List<CartItem>> {
  CartNotifier() : super([]);

  void addToCart(Product product) {
    final index = state.indexWhere(
          (item) => item.product.id == product.id,
    );

    if (index != -1) {
      state = [
        for (int i = 0; i < state.length; i++)
          if (i == index)
            state[i].copyWith(
              quantity: state[i].quantity + 1,
            )
          else
            state[i],
      ];
    } else {
      state = [
        ...state,
        CartItem(product: product),
      ];
    }
  }

  void removeFromCart(String productId) {
    state = state.where((item) => item.product.id != productId).toList();
  }

  void updateQuantity(String productId, int newQuantity) {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    state = [
      for (int i = 0; i < state.length; i++)
        if (state[i].product.id == productId)
          state[i].copyWith(quantity: newQuantity)
        else
          state[i],
    ];
  }

  void clearCart() {
    state = [];
  }
}

// Total harga keranjang
final cartTotalProvider = Provider<double>((ref) {
  final cart = ref.watch(cartProvider);
  return cart.fold(0, (sum, item) => sum + item.totalPrice);
});

// Jumlah item di keranjang
final cartItemCountProvider = Provider<int>((ref) {
  final cart = ref.watch(cartProvider);
  return cart.fold(0, (sum, item) => sum + item.quantity);
});

// Filter dan search
final categoryFilterProvider = StateProvider<String>((ref) => 'Semua');
final searchQueryProvider = StateProvider<String>((ref) => '');

// Produk yang sudah difilter
final filteredProductsProvider = Provider<List<Product>>((ref) {
  final products = ref.watch(productListProvider);
  final category = ref.watch(categoryFilterProvider);
  final searchQuery = ref.watch(searchQueryProvider).toLowerCase();

  return products.where((product) {
    final matchesCategory = category == 'Semua' || product.category == category;
    final matchesSearch = searchQuery.isEmpty ||
        product.name.toLowerCase().contains(searchQuery) ||
        product.category.toLowerCase().contains(searchQuery);
    return matchesCategory && matchesSearch;
  }).toList();
});